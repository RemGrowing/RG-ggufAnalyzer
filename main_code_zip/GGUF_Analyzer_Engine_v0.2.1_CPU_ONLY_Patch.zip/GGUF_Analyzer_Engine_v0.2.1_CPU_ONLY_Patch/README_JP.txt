GGUF Analyzer Engine v0.2.1 CPU-only conversion patch

重要:
このパッケージは、既存の GGUF_Analyzer_Engine_v0.2.0 プロジェクトへ適用する変換パッチです。
元のプロジェクト一式そのものではありません。既存プロジェクトの src/main.cpp、
src/gguf_engine.cpp、CMakeLists.txt をバックアップしたうえで CPU 専用構成に変更します。

変更内容:
- CUDA の検出・呼び出し・ビルドを除去し、物理走査を CPU バックエンドに固定
- GGUF 構造解析、メタデータ、テンソル、チャンク統計、エントロピー、JSON 出力を維持
- SHA-256 関数内の 1 MiB ローカル配列をヒープ確保へ変更
  (Windows の既定スタックサイズ付近で発生する STATUS_STACK_OVERFLOW の有力原因を回避)
- 変更前の3ファイルを backup_before_cpu_only_日時 フォルダへ保存

適用手順 (Windows PowerShell):
1. プロジェクトのルートへ移動:
   cd C:\Users\RemGrowing\OneDrive\Desktop\RemGrowing\RGPro\Project\gguf-analyzer\main_code\GGUF_Analyzer_Engine_v0.2.0

2. パッチをプロジェクトルートへコピーした場合:
   Set-ExecutionPolicy -Scope Process Bypass
   .\convert_gguf_analyzer_to_cpu_only.ps1

   別の場所に置いた場合はフルパスを指定:
   & 'C:\path\to\convert_gguf_analyzer_to_cpu_only.ps1' -ProjectRoot (Get-Location).Path

3. 古い CUDA ビルドキャッシュを使わず、新規 build_cpu ディレクトリで構成:
   cmake -S . -B build_cpu -G "Visual Studio 18 2026" -A x64
   cmake --build build_cpu --config Release --clean-first

   実行ファイル:
   .\build_cpu\Release\gguf_analyzer.exe

4. CLI確認:
   & .\build_cpu\Release\gguf_analyzer.exe --help

5. 解析テスト (SHA-256なし):
   $gguf = 'C:\Users\RemGrowing\.lmstudio\models\ManniX-ITA\Qwen3.6-27B-A3B-Coder-MTP-GGUF\Qwen3.6-27B-A3B-Coder-CD-Q4_K_M.gguf'
   $exe = Join-Path $PWD 'build_cpu\Release\gguf_analyzer.exe'
   $out = Join-Path $env:TEMP 'gguf_cpu_nohash.json'
   Remove-Item -LiteralPath $out -Force -ErrorAction SilentlyContinue
   & $exe $gguf --out $out --chunk-mib 64 --backend cpu --no-hash
   $rc = $LASTEXITCODE
   Write-Host "Exit code: $rc"
   Write-Host "JSON exists: $(Test-Path -LiteralPath $out -PathType Leaf)"

6. SHA-256込みの解析テスト:
   $outHash = Join-Path $env:TEMP 'gguf_cpu_sha256.json'
   Remove-Item -LiteralPath $outHash -Force -ErrorAction SilentlyContinue
   & $exe $gguf --out $outHash --chunk-mib 64 --backend cpu
   $rcHash = $LASTEXITCODE
   Write-Host "Exit code: $rcHash"
   Write-Host "JSON exists: $(Test-Path -LiteralPath $outHash -PathType Leaf)"

期待値:
- 正常な対象 GGUF なら終了コード 0、JSONファイルあり、走査率100%、Backend: cpu
- CUDA をビルド・実行しない
- --backend cuda はエラー終了する

注意:
- 変換パッチ自体はユーザーの Windows 環境でまだ実ビルド・実行していません。
- Visual Studio ジェネレーター名が異なる場合、cmake --help で利用可能なジェネレーターを確認してください。
- SHA-256は14.7 GBのファイル全体を追加で読み取るため、CPUとストレージ速度に応じて時間がかかります。
