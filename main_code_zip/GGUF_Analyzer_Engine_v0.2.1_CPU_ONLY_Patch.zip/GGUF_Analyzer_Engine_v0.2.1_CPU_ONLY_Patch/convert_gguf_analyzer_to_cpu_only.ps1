﻿param(
    [string]$ProjectRoot = (Get-Location).Path
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$srcDir = Join-Path $ProjectRoot 'src'
$enginePath = Join-Path $srcDir 'gguf_engine.cpp'
$mainPath = Join-Path $srcDir 'main.cpp'
$cmakePath = Join-Path $ProjectRoot 'CMakeLists.txt'

foreach ($p in @($srcDir, $enginePath, $mainPath, $cmakePath)) {
    if (-not (Test-Path -LiteralPath $p)) { throw "Required project path not found: $p" }
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupDir = Join-Path $ProjectRoot "backup_before_cpu_only_$stamp"
New-Item -ItemType Directory -Path $backupDir | Out-Null
Copy-Item -LiteralPath $enginePath -Destination (Join-Path $backupDir 'gguf_engine.cpp')
Copy-Item -LiteralPath $mainPath -Destination (Join-Path $backupDir 'main.cpp')
Copy-Item -LiteralPath $cmakePath -Destination (Join-Path $backupDir 'CMakeLists.txt')

$engine = Get-Content -LiteralPath $enginePath -Raw

# Fix the 1 MiB local stack allocation in sha256_file().
if ($engine -notmatch '(?m)^#include <vector>$') {
    $engine = $engine.Replace("#include <stdexcept>", "#include <stdexcept>`r`n#include <vector>")
}
$oldHashBuffer = 'std::array<char,1024*1024> input{};'
if (-not $engine.Contains($oldHashBuffer)) {
    throw 'Could not find the expected SHA-256 input buffer declaration; source files were not modified.'
}
$engine = $engine.Replace($oldHashBuffer, 'std::vector<char> input(1024*1024);')

# Replace CUDA/auto dispatch with CPU-only physical scan.
$cpuScan = @'
    // Independent full-file scan. This build intentionally supports CPU only.
    try {
      std::ifstream f(path,std::ios::binary);
      if(!f) throw std::runtime_error("cannot reopen file for physical scan");
      const auto scan_start=std::chrono::steady_clock::now();
      out.gpu_available=false;
      out.gpu_device.clear();
      out.gpu_chunks_processed=0;
      out.active_backend="cpu";
      std::vector<char> buffer(static_cast<size_t>(std::min<uint64_t>(opt.chunk_size, 256ull*1024ull*1024ull)));
      if(buffer.empty()) throw std::runtime_error("scan buffer size is zero");
      uint64_t off=0;
      while(off<out.file_size) {
        uint64_t n=std::min<uint64_t>(buffer.size(),out.file_size-off);
        f.clear(); f.seekg(static_cast<std::streamoff>(off),std::ios::beg);
        f.read(buffer.data(),static_cast<std::streamsize>(n));
        auto got=static_cast<uint64_t>(f.gcount());
        ScanChunk c{off,got,got==n,got==n ? "" : "short read or I/O error",{}};
        if(got>0) {
          c.stats=backend::analyze_cpu(reinterpret_cast<const unsigned char*>(buffer.data()),static_cast<size_t>(got));
          auto& a=out.aggregate_stats;
          a.zero_bytes+=c.stats.zero_bytes; a.nonzero_bytes+=c.stats.nonzero_bytes; a.sum_bytes+=c.stats.sum_bytes;
          if(c.stats.min_byte<a.min_byte) a.min_byte=c.stats.min_byte;
          if(c.stats.max_byte>a.max_byte) a.max_byte=c.stats.max_byte;
          for(size_t i=0;i<256;++i) a.histogram[i]+=c.stats.histogram[i];
        }
        out.chunks.push_back(c); out.bytes_scanned+=got; off+=got;
        if(got!=n) { issue(out,"error","CHUNK_READ_FAILED","Could not read complete chunk",c.offset); break; }
      }
      double entropy=0.0;
'@
$pattern = '(?s)// Independent full-file scan\..*?      double entropy=0\.0;'
$updatedEngine = [regex]::Replace($engine, $pattern, $cpuScan, 1)
if ($updatedEngine -eq $engine) {
    throw 'Could not replace the physical-scan backend block; source files were not modified.'
}
$engine = $updatedEngine

$main = @'
#include "gguf_engine.hpp"
#include <charconv>
#include <fstream>
#include <iostream>
#include <string>

static void help() {
    std::cout << "GGUF Analyzer Engine v0.2.1 CPU-only\n"
              << "Usage: gguf_analyzer <input.gguf> [--out report.json] [--chunk-mib N] [--backend cpu] [--no-hash]\n"
              << "  CPU byte-statistics backend only; CUDA code is not compiled or called.\n";
}

int main(int argc, char** argv) {
    if (argc < 2) { help(); return 2; }
    std::filesystem::path input = argv[1], output = "gguf_report.json";
    gguf::Options options;
    options.backend = "cpu";

    for (int i = 2; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--help") { help(); return 0; }
        else if (a == "--out" && i + 1 < argc) output = argv[++i];
        else if (a == "--chunk-mib" && i + 1 < argc) {
            uint64_t n = 0;
            std::string s = argv[++i];
            auto [p, ec] = std::from_chars(s.data(), s.data() + s.size(), n);
            if (ec != std::errc{} || p != s.data() + s.size() || n == 0 || n > 256) {
                std::cerr << "Invalid --chunk-mib (1..256 expected)\n";
                return 2;
            }
            options.chunk_size = n * 1024ull * 1024ull;
        } else if (a == "--backend" && i + 1 < argc) {
            options.backend = argv[++i];
            if (options.backend != "cpu") {
                std::cerr << "This build supports only --backend cpu\n";
                return 2;
            }
        } else if (a == "--no-hash") options.calculate_sha256 = false;
        else {
            std::cerr << "Unknown argument: " << a << "\n";
            help();
            return 2;
        }
    }

    try {
        gguf::Engine engine;
        auto report = engine.analyze(input, options);
        report.requested_backend = "cpu";

        std::ofstream out(output, std::ios::binary);
        if (!out) {
            std::cerr << "Cannot write report: " << output.string() << "\n";
            return 3;
        }
        out << gguf::report_to_json(report);
        out.close();
        if (!out) {
            std::cerr << "Failed while writing report: " << output.string() << "\n";
            return 3;
        }

        std::cout << "GGUF Analyzer Engine v0.2.1 CPU-only\n"
                  << "File size: " << report.file_size << " bytes\n"
                  << "Structure: " << report.structure_status << "\n"
                  << "Physical scan: " << report.bytes_scanned << " / " << report.file_size
                  << " bytes (" << report.coverage_percent << "%)\n"
                  << "Backend: " << report.active_backend << "\n"
                  << "Scan speed: " << report.scan_mib_per_second << " MiB/s ("
                  << report.scan_seconds << " s)\n"
                  << "Byte entropy: " << report.aggregate_stats.entropy_bits_per_byte
                  << " bits/byte\n"
                  << "Metadata: " << report.metadata.size() << " / "
                  << report.metadata_count_declared << "\n"
                  << "Tensors: " << report.tensors.size() << " / "
                  << report.tensor_count_declared << "\n"
                  << "SHA-256: " << (report.sha256.empty() ? "(not calculated)" : report.sha256) << "\n"
                  << "Issues: " << report.issues.size() << "\n"
                  << "Report: " << output.string() << "\n";

        return report.structure_parse_ok && report.coverage_percent == 100.0 ? 0 : 1;
    } catch (const std::exception& e) {
        std::cerr << "Fatal: " << e.what() << "\n";
        return 10;
    }
}
'@

$cmake = @'
cmake_minimum_required(VERSION 3.24)
project(GGUF_Analyzer_Engine_v0_2_1_CPU_ONLY LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_executable(gguf_analyzer
    src/main.cpp
    src/gguf_engine.cpp
    src/backend_cpu.cpp
)

target_include_directories(gguf_analyzer PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")

if(MSVC)
    target_compile_options(gguf_analyzer PRIVATE /W4 /permissive- /EHsc)
else()
    target_compile_options(gguf_analyzer PRIVATE -Wall -Wextra -Wpedantic)
endif()

message(STATUS "GGUF Analyzer Engine v0.2.1: CPU-only build; CUDA is disabled.")
'@

# Write only after transformations have succeeded.
Set-Content -LiteralPath $enginePath -Value $engine -Encoding utf8
Set-Content -LiteralPath $mainPath -Value $main -Encoding utf8
Set-Content -LiteralPath $cmakePath -Value $cmake -Encoding utf8

Write-Host ''
Write-Host 'CPU-only conversion completed.' -ForegroundColor Green
Write-Host "Backup: $backupDir"
Write-Host 'Changes: CUDA dispatch removed; CPU scan retained; SHA-256 1 MiB buffer moved from stack to heap.'
Write-Host 'Next: configure a fresh build directory named build_cpu, then build and test.'
